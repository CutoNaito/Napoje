<footer>
    <div class="footer">
        <a href="https://github.com/CutoNaito/napoje-ajax"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Octicons-mark-github.svg/2048px-Octicons-mark-github.svg.png" alt="GitHub"></img></a>
    </div>
</footer>